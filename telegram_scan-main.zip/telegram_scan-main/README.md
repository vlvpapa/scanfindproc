# telegram_scan
Fantastic and full featured framework for Telegram users and chats investigating.

Prerequisites:
1. pip3 install pyrogram;
2. get api_id and api_hash at https://my.telegram.org/auth and insert the ones into access_creds.py.

This framework has 16 modules to get all one needs to know about Telegram users and chats. 

Feel free to enhance telegram_scan and write your own modules!

Run command:        python3 telegram_scan.py
